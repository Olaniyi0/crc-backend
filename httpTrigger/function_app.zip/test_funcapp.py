from visitorCounter import main
import unittest

class TestVisitorCoounter():

    def test_visitor_counter(self):
        pass